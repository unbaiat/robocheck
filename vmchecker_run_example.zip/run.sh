#!/bin/sh

home=$1
cd $home

run_tests()
{
    echo -e "\nchecker: testing"

    if [ -f _checker.sh ]; then sh _checker.sh; elif [ -f Makefile.checker ]; then make -f Makefile.checker run ; else echo dont know how to run tests; fi  2>&1
}

run_robocheck()
{
	# Run robocheck config
	export LD_LIBRARY_PATH=/robocheck/repo/
	export PATH=/robocheck/repo/:$PATH
	chmod +x robocheck_config.sh

	./robocheck_config.sh
	cat rbc_config.xml

	# Run robocheck
	robocheck > __robocheck_temp
	python robocheck_parser.py __robocheck_temp > robocheck.vmr
	rm __robocheck_temp
}

run_robocheck
run_tests > run-stdout.vmr 2> run-stderr.vmr
